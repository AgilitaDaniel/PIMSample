sap.ui.define(["sap/ui/model/Filter","sap/ui/model/FilterOperator"],function(e,i){"use strict";return{filterItems:function(e){}}});
//# sourceMappingURL=CustomFilter.js.map